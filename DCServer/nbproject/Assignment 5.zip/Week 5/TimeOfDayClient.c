#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<arpa/inet.h>
#include<sys/socket.h>

#define BUFLEN 512  //Max length of buffer
 
void die(char *s)
{
    perror(s);
    exit(1);
}
/* Param:
	1) IP Address of Server
	2) Port of Server
*/
int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Wrong number of arguments !!\n");
        exit(1);
    }
    struct sockaddr_in si_other;
    int s, i, slen=sizeof(si_other);
    char buf[BUFLEN];
    char message[BUFLEN];
    if ( (s=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
        die("socket");
    }
    memset((char *) &si_other, 0, sizeof(si_other));
    si_other.sin_family = AF_INET;
    si_other.sin_port = htons(atoi(argv[2]));
    if (inet_aton(argv[1], &si_other.sin_addr) == 0) {
        fprintf(stderr, "inet_aton() failed\n");
        exit(1);
    }
    while(1) {
	    printf("Enter \"get\" to make request : ");
	    scanf("%s",message);
	    if (sendto(s, message, strlen(message) , 0 , (struct sockaddr *) &si_other, slen)==-1) {
			die("sendto()");
	    }
	    memset(buf,'\0', BUFLEN);
	    if (recvfrom(s, buf, BUFLEN, 0, (struct sockaddr *) &si_other, &slen) == -1) {
			die("recvfrom()");
	    }
	    printf("Time received from Server: %s\n",buf);
    }
    close(s);
    return 0;
}
